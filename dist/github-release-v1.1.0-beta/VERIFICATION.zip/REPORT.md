# v1.1.0-beta verification

Local verification: 2026-10-29. Firmware target: heltec_v4_companion_radio_ble.
One image contains BLE companion services and health monitoring.

Source commit: cbe2b9d8057533d591bd4326c6a149c6447e9515
Maintained-source identity: 88e2d1103dadfe35d2deece927a220795b4cee4a8dfb9e8f1d2f894887e667a7
Build started clean. Only release documentation and generated assets changed.
No maintained firmware input drift occurred. No dependencies were upgraded.
Package listing initially failed with a Windows console encoding error; retry
with PYTHONIOENCODING=utf-8 passed. Both outcomes are retained.

Clean rebuild/merge passed. Native: 771 cases passed; Python: 62 tests passed.
Fresh fixture replay: 1007 records, 944 samples, three identical runs.
ESP32-S3 bootloader and application checksums and validation hashes are valid.
Partition MD5 checked; component offsets 0x0, 0x8000, 0xe000 and 0x10000
match bootloader, partitions, boot_app0 and application bytes exactly.
Actual image: DIO, 80 MHz, 16 MB. Esptool retained the hash-protected bootloader
header despite the board's QIO merge option; this warning is preserved in logs.

Installation asset: SHN_v1.1.0-beta_firmware-merged.bin
Size: 1396080 bytes
SHA-256: 0629c5640a3300600807c7967cb167f2ec8292824e414f5c3b2f15438c5e139f
Flash the merged image at 0x0. Consult the maintained installation guide.

commands.json records command results; logs retain build/test details.
manifest.json records candidate identity, packages and component hashes.
source-manifest.json fingerprints exact maintained input bytes, including paths.
inventory.json hashes every other archive member; SHA256SUMS.txt outside this
archive checks the firmware and the final archive. Neither inventory hashes itself.
No credentials or configuration contents are included. Local paths in logs are redacted.

No hardware was flashed, and physical BLE, RF, sensing, buzzer output, power-loss
durability and fall-detection accuracy remain unverified. No hosted CI ran.
Nothing was committed, tagged or published. Hashes do not authenticate a publisher.
